import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;
import javax.swing.JRadioButton;

import java.awt.FlowLayout;

import javax.swing.ButtonGroup;

import java.awt.Color;

import javax.swing.JMenuBar;
import javax.swing.JPopupMenu;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JMenuItem;
import javax.swing.JMenu;

import java.awt.Font;

public class ShowBoard {

	private JFrame frame;
	private JTextField txtTictactoeGame;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JButton btnNewButton_5;
	private JButton btnNewButton_6;
	private JButton btnNewButton_7;
	private JButton btnNewButton_8;
	private JButton btnNewButton_9;
	private JButton btnNewButton_10;
	private JButton btnNewButton_11;
	public static String humanPlayer = "X";
	public static String computerPlayer = "O";
	private boolean isHardMode = false;
	private boolean isPVP = false;
	private JMenuBar menuBar;
	private JMenu optionMenu;
	private JMenu menuPVC;
	private JMenuItem menuPVP;
	private JMenuItem mntmNewMenuItem;
	private JMenuItem mntmNewMenuItem_1;
	public JTextField txtState;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		TicTacToe game = new TicTacToe();
		game.initializeBoard();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowBoard window = new ShowBoard(game);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ShowBoard(TicTacToe game) {
		initialize(game);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(TicTacToe game) {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		txtTictactoeGame = new JTextField();
		txtTictactoeGame.setFont(new Font("Arial Black", Font.PLAIN, 12));
		txtTictactoeGame.setEnabled(false);
		txtTictactoeGame.setForeground(Color.BLACK);
		txtTictactoeGame.setBackground(Color.CYAN);
		txtTictactoeGame.setHorizontalAlignment(SwingConstants.CENTER);
		txtTictactoeGame.setText("Tic-Tac-Toe Game");
		frame.getContentPane().add(txtTictactoeGame, BorderLayout.NORTH);
		txtTictactoeGame.setColumns(10);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.SOUTH);
		
		
		JPanel panel_1 = new JPanel();
		frame.getContentPane().add(panel_1, BorderLayout.WEST);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Choose O");
		rdbtnNewRadioButton.setBackground(Color.ORANGE);
		buttonGroup.add(rdbtnNewRadioButton);
		panel_1.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				game.setCurrentPlayerMark("O");
				humanPlayer = "O";
				computerPlayer = "X";
			}
		});
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Choose X");
		rdbtnNewRadioButton_1.setBackground(Color.ORANGE);
		buttonGroup.add(rdbtnNewRadioButton_1);
		panel_1.add(rdbtnNewRadioButton_1, BorderLayout.NORTH);
		rdbtnNewRadioButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				game.setCurrentPlayerMark("X");
				humanPlayer = "X";
				computerPlayer= "O";
			}
		});
		
		JButton btnNewButton_2 = new JButton("MUSIC ON");
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MusicThread.musicType = 1;
				new MusicThread().run();
			}
		});
		panel_1.add(btnNewButton_2, BorderLayout.SOUTH);
		
		JPanel panel_2 = new JPanel();
		frame.getContentPane().add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new GridLayout(3,3));
		
		btnNewButton_3 = new JButton("-");
		btnNewButton_3.setForeground(Color.BLACK);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(0, 0)){				
					btnNewButton_3.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());
				}			
			}
		});
		panel_2.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("-");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(0, 1)){				
					btnNewButton_4.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());
				}				
			}
		});
		panel_2.add(btnNewButton_4);
		
		btnNewButton_6 = new JButton("-");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(0, 2)){				
					btnNewButton_6.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());	
				}			
			}
		});
		panel_2.add(btnNewButton_6);
		
		btnNewButton_5 = new JButton("-");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(1, 0)){				
					btnNewButton_5.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());
				}			
			}
		});
		panel_2.add(btnNewButton_5);
		
		btnNewButton_7 = new JButton("-");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(1, 1)){				
					btnNewButton_7.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());
				}			
			}
		});
		panel_2.add(btnNewButton_7);
		
		btnNewButton_8 = new JButton("-");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(1, 2)){				
					btnNewButton_8.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());
				}			
			}
		});
		panel_2.add(btnNewButton_8);
		
		btnNewButton_9 = new JButton("-");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(2, 0)){				
					btnNewButton_9.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());	
				}			
			}
		});
		panel_2.add(btnNewButton_9);
		
		btnNewButton_10 = new JButton("-");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(2, 1)){				
					btnNewButton_10.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());	
				}			
			}
		});
		panel_2.add(btnNewButton_10);
		
		btnNewButton_11 = new JButton("-");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(game.placeMark(2, 2)){				
					btnNewButton_11.setText(game.getCurrentPlayerMark());
					checkWinning(game, game.getCurrentPlayerMark());
				}			
			}
		});
		panel_2.add(btnNewButton_11);
		
		JButton btnNewButton = new JButton("Exit");
		btnNewButton.setForeground(Color.BLUE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.setForeground(Color.BLUE);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				game.initializeBoard();
				initUIBoard();
			}
		});
		
		menuBar = new JMenuBar();
		panel.add(menuBar);
		
		optionMenu = new JMenu("Opponent Option");
		menuBar.add(optionMenu);
		
		menuPVC = new JMenu("PVC");
		optionMenu.add(menuPVC);
		
		mntmNewMenuItem = new JMenuItem("Easy Mode");
		menuPVC.add(mntmNewMenuItem);
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isPVP = false;
				isHardMode = false;
				txtState.setText("Single Player---Easy Mode");
			}
		});
		
		mntmNewMenuItem_1 = new JMenuItem("Hard mode");
		menuPVC.add(mntmNewMenuItem_1);
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isPVP = false;
				isHardMode = true;
				txtState.setText("Single Player---Hard Mode");
			}
		});
		
		menuPVP = new JMenuItem("PVP");
		optionMenu.add(menuPVP);
		menuPVP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				isPVP = true;
				txtState.setText("Player VS Player");
			}
		});
		
		txtState = new JTextField();
		txtState.setBackground(Color.BLACK);
		txtState.setForeground(Color.WHITE);
		txtState.setText("Welcome to TTT World!");
		panel.add(txtState);
		txtState.setColumns(15);
		txtState.setEnabled(false);
		
		panel.add(btnNewButton_1);
		panel.add(btnNewButton);

	}

	private void AIOperation(int[]position){
		int row = position[0];
		int col = position[1];		
		if(row==0&&col==0){
			btnNewButton_3.doClick();
		}
		if(row==0&&col==1){
			btnNewButton_4.doClick();
		}
		if(row==0&&col==2){
			btnNewButton_6.doClick();
		}
		if(row==1&&col==0){
			btnNewButton_5.doClick();
		}
		if(row==1&&col==1){
			btnNewButton_7.doClick();
		}
		if(row==1&&col==2){
			btnNewButton_8.doClick();
		}
		if(row==2&&col==0){
			btnNewButton_9.doClick();
		}
		if(row==2&&col==1){
			btnNewButton_10.doClick();
		}
		if(row==2&&col==2){
			btnNewButton_11.doClick();
		}
	}
	
	private void initUIBoard(){
		btnNewButton_3.setText("-");
		btnNewButton_4.setText("-");
		btnNewButton_5.setText("-");
		btnNewButton_6.setText("-");
		btnNewButton_7.setText("-");
		btnNewButton_8.setText("-");
		btnNewButton_9.setText("-");
		btnNewButton_10.setText("-");
		btnNewButton_11.setText("-");
	}
	private void checkWinning(TicTacToe game, String player){
		if(game.checkForWin()){
			if(isPVP==false){
				if(player.equals(humanPlayer)){
					JOptionPane.showMessageDialog(frame, "you win!");
					MusicThread.musicType = 2;
					new MusicThread().run();
				}else{
					JOptionPane.showMessageDialog(frame, "you lose!");
					MusicThread.musicType = 3;
					new MusicThread().run();
				}

			}else{
				JOptionPane.showMessageDialog(frame, "game over! winner is: "+game.getCurrentPlayerMark());
			}
			game.initializeBoard();
			game.setCurrentPlayerMark("X");
			humanPlayer = "X";
			computerPlayer = "O";
			initUIBoard();
		}else{
			if(game.isBoardFull()){
				JOptionPane.showMessageDialog(frame,
					    "tie game!");
				MusicThread.musicType = 4;
				new MusicThread().run();
				game.initializeBoard();
				game.setCurrentPlayerMark("X");
				humanPlayer = "X";
				computerPlayer = "O";
				initUIBoard();
			}else{				
				game.changePlayer();
				if(game.getCurrentPlayerMark().equals(computerPlayer) && isPVP==false){
					if(isHardMode == true){
						AIOperation(game.AIPlaceMark());
					}else{
						AIOperation(game.naiveAIPlaceMark());
					}
				}

			}
		}
	
   }

}
