import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TicTacToe {

    private String[][] board; 
    private String currentPlayerMark;
    public static int butClicked = 0;
    public String getCurrentPlayerMark() {
		return currentPlayerMark;
	}


	public TicTacToe() {
        board = new String[3][3];
        currentPlayerMark = "X";
        initializeBoard();
    }
	
	
    // Set/Reset the board back to all empty values.
    public void initializeBoard() {
		
        // Loop through rows
        for (int i = 0; i < 3; i++) {
			
            // Loop through columns
            for (int j = 0; j < 3; j++) {
                board[i][j] = "-";
            }
        }
    }
	
 
    
    public void setCurrentPlayerMark(String currentPlayerMark) {
		this.currentPlayerMark = currentPlayerMark;
	}


	// Print the current board (may be replaced by GUI implementation later)
    public void printBoard() {
        System.out.println("-------------");
		
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j] + " | ");
            }
            System.out.println();
            System.out.println("-------------");
        }
    }
	
	
    // Loop through all cells of the board and if one is found to be empty (contains char '-') then return false.
    // Otherwise the board is full.
    public boolean isBoardFull() {
        boolean isFull = true;
		
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == "-") {
                    isFull = false;
                }
            }
        }
		
        return isFull;
    }
	
	
    // Returns true if there is a win, false otherwise.
    // This calls our other win check functions to check the entire board.
    public boolean checkForWin() {
        return (checkRowsForWin() || checkColumnsForWin() || checkDiagonalsForWin());
    }
	
	
    // Loop through rows and see if any are winners.
    private boolean checkRowsForWin() {
        for (int i = 0; i < 3; i++) {
            if (checkRowCol(board[i][0], board[i][1], board[i][2]) == true) {
                return true;
            }
        }
        return false;
    }
	
	
    // Loop through columns and see if any are winners.
    private boolean checkColumnsForWin() {
        for (int i = 0; i < 3; i++) {
            if (checkRowCol(board[0][i], board[1][i], board[2][i]) == true) {
                return true;
            }
        }
        return false;
    }
	
	
    // Check the two diagonals to see if either is a win. Return true if either wins.
    private boolean checkDiagonalsForWin() {
        return ((checkRowCol(board[0][0], board[1][1], board[2][2]) == true) || (checkRowCol(board[0][2], board[1][1], board[2][0]) == true));
    }
	
	
    // Check to see if all three values are the same (and not empty) indicating a win.
    private boolean checkRowCol(String c1, String c2, String c3) {
        return ((!c1.equals("-")) && (c1.equals(c2)) && (c2.equals(c3)));
    }
	
	
    // Change player marks back and forth.
    public void changePlayer() {
        if (currentPlayerMark.equals("X")) {
            currentPlayerMark = "O";
        }
        else {
            currentPlayerMark = "X";
        }
    }
	
	
    // Places a mark at the cell specified by row and col with the mark of the current player.
    public boolean placeMark(int row, int col) {
		
        // Make sure that row and column are in bounds of the board.
        if ((row >= 0) && (row < 3)) {
            if ((col >= 0) && (col < 3)) {
                if (board[row][col].equals("-")) {
                    board[row][col] = this.currentPlayerMark;
                    return true;
                }
            }
        }
		
        return false;
    }
    
    public int[] AIPlaceMark() {
        int[] result = minimax(2, "O"); // depth, max turn
        //board[result[1]][result[2]] = "O";      
        return new int[]{result[1],result[2]};
     }
    
    public int[] naiveAIPlaceMark(){
    	List<int[]> nextMoves = generateMoves();
    	Random r = new Random();
    	if (nextMoves.isEmpty()){
    		return new int[]{5,5};
    	}else{
    		int index = r.nextInt(nextMoves.size());
    		return nextMoves.get(index);
    	}
    }
    
    
    private int[] minimax(int depth, String player) {
        // Generate possible next moves in a List of {row, col}.
        List<int[]> nextMoves = generateMoves();
   
        // mySeed is maximizing; while oppSeed is minimizing
        int bestScore = (player.equals("O")) ? Integer.MIN_VALUE : Integer.MAX_VALUE;
        int currentScore;
        int bestRow = -1;
        int bestCol = -1;
   
        if (nextMoves.isEmpty() || depth == 0) {
           // Game over or depth reached, evaluate score
           bestScore = evaluate();
        } else {
           for (int[] move : nextMoves) {
              // Try this move for the current "player"
              board[move[0]][move[1]]= player;
              if (player.equals("O")) {  // mySeed (computer) is maximizing player
                 currentScore = minimax(depth - 1, "X")[0];
                 if (currentScore > bestScore) {
                    bestScore = currentScore;
                    bestRow = move[0];
                    bestCol = move[1];
                 }
              } else {  // oppSeed is minimizing player
                 currentScore = minimax(depth - 1, "O")[0];
                 if (currentScore < bestScore) {
                    bestScore = currentScore;
                    bestRow = move[0];
                    bestCol = move[1];
                 }
              }
              // Undo move
              board[move[0]][move[1]]= "-";
           }
        }
        return new int[] {bestScore, bestRow, bestCol};
     }
    
    /** Find all valid next moves */
    private List<int[]> generateMoves(){
    	 List<int[]> nextMoves = new ArrayList<int[]>(); // allocate List
    	 
         // If game over, i.e., no next move
         if (checkForWin()) {
            return nextMoves;   // return empty list
         }
    
         // Search for empty cells and add to the List
         for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
               if (board[row][col].equals("-")) {
                  nextMoves.add(new int[] {row, col});
               }
            }
         }
         return nextMoves;
    }
    
    private int evaluate() {
        int score = 0;
        // Evaluate score for each of the 8 lines (3 rows, 3 columns, 2 diagonals)
        score += evaluateLine(0, 0, 0, 1, 0, 2);  // row 0
        score += evaluateLine(1, 0, 1, 1, 1, 2);  // row 1
        score += evaluateLine(2, 0, 2, 1, 2, 2);  // row 2
        score += evaluateLine(0, 0, 1, 0, 2, 0);  // col 0
        score += evaluateLine(0, 1, 1, 1, 2, 1);  // col 1
        score += evaluateLine(0, 2, 1, 2, 2, 2);  // col 2
        score += evaluateLine(0, 0, 1, 1, 2, 2);  // diagonal
        score += evaluateLine(0, 2, 1, 1, 2, 0);  // alternate diagonal
        return score;
    }
    
    /** The heuristic evaluation function for the given line of 3 cells
    @Return +100, +10, +1 for 3-, 2-, 1-in-a-line for computer.
            -100, -10, -1 for 3-, 2-, 1-in-a-line for opponent.
            0 otherwise */
private int evaluateLine(int row1, int col1, int row2, int col2, int row3, int col3) {
   int score = 0;

   // First cell
   if (board[row1][col1].equals("O")) {
      score = 1;
   } else if (board[row1][col1].equals("X")) {
      score = -1;
   }

   // Second cell
   if (board[row2][col2].equals("O")) {
      if (score == 1) {   // cell1 is mySeed
         score = 10;
      } else if (score == -1) {  // cell1 is oppSeed
         return 0;
      } else {  // cell1 is empty
         score = 1;
      }
   } else if (board[row2][col2].equals("X")) {
      if (score == -1) { // cell1 is oppSeed
         score = -10;
      } else if (score == 1) { // cell1 is mySeed
         return 0;
      } else {  // cell1 is empty
         score = -1;
      }
   }

   // Third cell
   if (board[row3][col3].equals("O")) {
      if (score > 0) {  // cell1 and/or cell2 is mySeed
         score *= 10;
      } else if (score < 0) {  // cell1 and/or cell2 is oppSeed
         return 0;
      } else {  // cell1 and cell2 are empty
         score = 1;
      }
   } else if (board[row3][col3].equals("X")) {
      if (score < 0) {  // cell1 and/or cell2 is oppSeed
         score *= 10;
      } else if (score > 1) {  // cell1 and/or cell2 is mySeed
         return 0;
      } else {  // cell1 and cell2 are empty
         score = -1;
      }
   }
   return score;
}
   
}