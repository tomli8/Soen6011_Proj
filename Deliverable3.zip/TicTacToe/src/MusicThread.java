import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;

class MusicThread extends Thread{
	public static int musicType = 0;
	private AudioClip ac; 
	private AudioClip ac2; 
	public AudioClip getAc() {
		return ac;
	}
	private AudioClip ac3; 
	private AudioClip ac4; 
	public void run(){
		try{
			   URL url = new URL("file:" + "./background.wav"); 
			   URL url2 = new URL("file:" + "./victory.wav"); 
			   URL url3= new URL("file:" + "./fail.wav"); 
			   URL url4= new URL("file:" + "./tie.wav"); 
			   ac = Applet.newAudioClip(url); 
			   ac2 = Applet.newAudioClip(url2); 
			   ac3 = Applet.newAudioClip(url3); 
			   ac4 = Applet.newAudioClip(url4); 
			   
			   musicPlay(); 
			  }catch(Exception e){
			   e.printStackTrace();
			  }
	}
	public void musicPlay(){
		switch(musicType){
		case 1:ac.play(); break;
		case 2:ac2.play(); break;
		case 3:ac3.play(); break;
		case 4:ac4.play(); break;
			
		}

	}
}